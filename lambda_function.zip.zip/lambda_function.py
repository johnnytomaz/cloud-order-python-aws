import json

def lambda_handler(event, context):
    try:
        body = json.loads(event.get('body', '{}'))
        
        if not body.get('cliente_id') or not body.get('valor'):
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Dados incompletos'})
            }

        return {
            'statusCode': 200,
            'body': json.dumps({'message': 'Sucesso!', 'pedido': body})
        }
    except Exception as e:
        return {'statusCode': 500, 'body': json.dumps({'error': str(e)})}